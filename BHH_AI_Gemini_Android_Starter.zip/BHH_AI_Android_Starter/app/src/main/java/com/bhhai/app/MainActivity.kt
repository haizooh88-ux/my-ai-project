package com.bhhai.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.HttpUrl.Companion.toHttpUrl
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

private val Bg = Color(0xFF0E0918)
private val Panel = Color(0xFF191127)
private val Panel2 = Color(0xFF281A3D)
private val Accent = Color(0xFFB889FF)
private val Txt = Color(0xFFF7F0FF)
private val Muted = Color(0xFFB5A8C9)

data class ChatMessage(val role: String, val content: String)
data class ChatThread(val id: String, val title: String, val messages: List<ChatMessage>)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { BhhApp() }
    }
}

@Composable
fun BhhApp() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val prefs = remember { context.getSharedPreferences("bhh_settings", 0) }
    var baseUrl by remember { mutableStateOf(prefs.getString("url", "") ?: "") }
    var model by remember { mutableStateOf(prefs.getString("model", "") ?: "") }
    var apiKey by remember { mutableStateOf(prefs.getString("key", "") ?: "") }
    var systemPrompt by remember { mutableStateOf(prefs.getString("prompt", "أنت BHH AI، مساعد مفيد. أجب باللغة التي يستخدمها المستخدم.") ?: "") }
    var showSettings by remember { mutableStateOf(false) }
    var draft by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()
    var threads by remember { mutableStateOf(listOf(ChatThread(UUID.randomUUID().toString(), "محادثة جديدة", emptyList()))) }
    var activeId by remember { mutableStateOf(threads.first().id) }
    val active = threads.firstOrNull { it.id == activeId } ?: threads.first()
    val listState = rememberLazyListState()

    fun updateMessages(newMessages: List<ChatMessage>, newTitle: String? = null) {
        threads = threads.map { if (it.id == activeId) it.copy(messages = newMessages, title = newTitle ?: it.title) else it }
    }
    fun newChat() {
        val t = ChatThread(UUID.randomUUID().toString(), "محادثة جديدة", emptyList())
        threads = listOf(t) + threads
        activeId = t.id
        status = ""
    }

    MaterialTheme(colorScheme = darkColorScheme(
        background = Bg, surface = Panel, primary = Accent, onPrimary = Bg,
        onBackground = Txt, onSurface = Txt, secondary = Muted
    )) {
        Surface(Modifier.fillMaxSize(), color = Bg) {
            Column(Modifier.fillMaxSize()) {
                Row(
                    Modifier.fillMaxWidth().background(Bg).padding(horizontal = 16.dp, vertical = 14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f)) {
                        Text("BHH AI", fontSize = 21.sp, fontWeight = FontWeight.Bold, color = Txt)
                        Text("مساعدك الذكي الشخصي", fontSize = 12.sp, color = Accent)
                    }
                    IconButton(onClick = { newChat() }) { Icon(Icons.Default.Add, "محادثة جديدة", tint = Txt) }
                    IconButton(onClick = { showSettings = true }) { Icon(Icons.Default.Settings, "الإعدادات", tint = Txt) }
                }
                HorizontalDivider(color = Panel2)
                if (active.messages.isEmpty()) {
                    Column(
                        Modifier.weight(1f).fillMaxWidth().padding(22.dp),
                        verticalArrangement = Arrangement.Center,
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Box(Modifier.size(62.dp).background(Panel2, CircleShape), contentAlignment = Alignment.Center) {
                            Text("B", color = Accent, fontSize = 30.sp, fontWeight = FontWeight.Bold)
                        }
                        Spacer(Modifier.height(20.dp))
                        Text("شلون أگدر أساعدك؟", fontSize = 25.sp, fontWeight = FontWeight.SemiBold, color = Txt)
                        Spacer(Modifier.height(8.dp))
                        Text("اكتب سؤالك وابدأ محادثة جديدة", color = Muted, fontSize = 14.sp)
                        Spacer(Modifier.height(22.dp))
                        listOf("ساعدني أكتب فكرة", "اشرح لي موضوع", "اكتب لي كود", "اقترح أفكار جديدة").forEach { suggestion ->
                            Box(
                                Modifier.fillMaxWidth().padding(vertical = 4.dp)
                                    .background(Panel, RoundedCornerShape(14.dp))
                                    .clickable { draft = suggestion }.padding(14.dp)
                            ) { Text(suggestion, color = Txt, fontSize = 14.sp) }
                        }
                    }
                } else {
                    LazyColumn(
                        Modifier.weight(1f).fillMaxWidth().padding(horizontal = 12.dp),
                        state = listState,
                        contentPadding = PaddingValues(vertical = 14.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        itemsIndexed(active.messages) { _, msg ->
                            val user = msg.role == "user"
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = if (user) Arrangement.Start else Arrangement.End) {
                                Column(
                                    Modifier.fillMaxWidth(0.92f)
                                        .background(if (user) Panel2 else Panel, RoundedCornerShape(16.dp))
                                        .padding(14.dp)
                                ) {
                                    Text(if (user) "أنت" else "BHH AI", color = Accent, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                                    Spacer(Modifier.height(5.dp))
                                    Text(msg.content, color = Txt, fontSize = 15.sp, lineHeight = 23.sp)
                                }
                            }
                        }
                        if (busy) item { Text("BHH AI يكتب...", color = Muted, modifier = Modifier.padding(8.dp)) }
                    }
                    LaunchedEffect(active.messages.size, busy) {
                        if (active.messages.isNotEmpty()) listState.animateScrollToItem(active.messages.size - 1)
                    }
                }
                if (status.isNotBlank()) Text(status, color = if (status.startsWith("خطأ")) Color(0xFFFF9292) else Muted, modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp), fontSize = 12.sp)
                Row(
                    Modifier.fillMaxWidth().padding(start = 12.dp, end = 12.dp, bottom = 12.dp, top = 8.dp)
                        .background(Panel, RoundedCornerShape(25.dp)).padding(start = 16.dp, end = 7.dp, top = 8.dp, bottom = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    BasicTextField(
                        value = draft, onValueChange = { draft = it },
                        modifier = Modifier.weight(1f).padding(vertical = 8.dp),
                        textStyle = androidx.compose.ui.text.TextStyle(color = Txt, fontSize = 15.sp),
                        cursorBrush = androidx.compose.ui.graphics.SolidColor(Accent),
                        decorationBox = { inner ->
                            Box {
                                if (draft.isEmpty()) Text("اكتب رسالتك هنا...", color = Muted, fontSize = 15.sp)
                                inner()
                            }
                        },
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                        keyboardActions = KeyboardActions(onSend = {
                            if (draft.isNotBlank() && !busy) {
                                val message = draft.trim(); draft = ""
                                val previous = active.messages
                                val now = previous + ChatMessage("user", message)
                                updateMessages(now, if (previous.isEmpty()) message.take(28) else null)
                                busy = true; status = ""
                                scope.launch {
                                    try {
                                        val answer = callAi(baseUrl, model, apiKey, systemPrompt, now)
                                        updateMessages(now + ChatMessage("assistant", answer))
                                    } catch (e: Exception) { status = "خطأ: ${e.message ?: "تعذر الاتصال"}" }
                                    finally { busy = false }
                                }
                            }
                        })
                    )
                    Spacer(Modifier.width(8.dp))
                    IconButton(
                        enabled = draft.isNotBlank() && !busy,
                        onClick = {
                            val message = draft.trim(); draft = ""
                            val previous = active.messages
                            val now = previous + ChatMessage("user", message)
                            updateMessages(now, if (previous.isEmpty()) message.take(28) else null)
                            busy = true; status = ""
                            scope.launch {
                                try {
                                    val answer = callAi(baseUrl, model, apiKey, systemPrompt, now)
                                    updateMessages(now + ChatMessage("assistant", answer))
                                } catch (e: Exception) { status = "خطأ: ${e.message ?: "تعذر الاتصال"}" }
                                finally { busy = false }
                            }
                        },
                        modifier = Modifier.size(42.dp).background(if (draft.isNotBlank() && !busy) Accent else Panel2, CircleShape)
                    ) { Icon(Icons.Default.ArrowUpward, "إرسال", tint = if (draft.isNotBlank() && !busy) Bg else Muted) }
                }
            }
        }
        if (showSettings) {
            AlertDialog(
                onDismissRequest = { showSettings = false },
                containerColor = Panel,
                title = { Text("إعدادات BHH AI", color = Txt) },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("إعدادات محرك الذكاء الاصطناعي", color = Accent, fontSize = 12.sp)
                        OutlinedTextField(baseUrl, { baseUrl = it }, label = { Text("عنوان API (Gemini: https://generativelanguage.googleapis.com/v1beta)") }, singleLine = true)
                        OutlinedTextField(model, { model = it }, label = { Text("Model") }, singleLine = true)
                        OutlinedTextField(apiKey, { apiKey = it }, label = { Text("مفتاح API") }, singleLine = true, visualTransformation = PasswordVisualTransformation())
                        OutlinedTextField(systemPrompt, { systemPrompt = it }, label = { Text("تعليمات المساعد") }, minLines = 3)
                        Text("لـ Gemini استخدم عنوان generativelanguage.googleapis.com/v1beta واسم موديل متاح مثل gemini-2.5-flash. المفتاح داخل التطبيق مناسب للتجربة فقط؛ للنشر استخدم خادماً وسيطاً آمناً.", color = Muted, fontSize = 12.sp)
                    }
                },
                confirmButton = {
                    TextButton(onClick = {
                        prefs.edit().putString("url", baseUrl.trim()).putString("model", model.trim())
                            .putString("key", apiKey).putString("prompt", systemPrompt).apply()
                        showSettings = false; status = "تم حفظ الإعدادات على هذا الجهاز"
                    }) { Text("حفظ") }
                },
                dismissButton = { TextButton(onClick = { showSettings = false }) { Text("إلغاء") } }
            )
        }
    }
}

private suspend fun callAi(
    baseUrl: String, model: String, apiKey: String, systemPrompt: String, messages: List<ChatMessage>
): String = withContext(Dispatchers.IO) {
    if (baseUrl.isBlank() || model.isBlank() || apiKey.isBlank()) {
        throw IllegalStateException("افتح الإعدادات وأدخل عنوان API واسم الموديل ومفتاح API")
    }
    val normalized = baseUrl.trim().trimEnd('/')
    val client = OkHttpClient()
    val isAnthropic = normalized.contains("anthropic.com", ignoreCase = true)
    val isGemini = normalized.contains("generativelanguage.googleapis.com", ignoreCase = true)
        || normalized.contains("googleapis.com", ignoreCase = true)
    val bodyJson: JSONObject
    val request: Request

    if (isGemini) {
        val contents = JSONArray()
        messages.filter { it.role == "user" || it.role == "assistant" || it.role == "model" }.forEach { message ->
            val role = if (message.role == "assistant") "model" else message.role
            val parts = JSONArray().put(JSONObject().put("text", message.content))
            contents.put(JSONObject().put("role", role).put("parts", parts))
        }
        bodyJson = JSONObject().put("contents", contents)
            .put("generationConfig", JSONObject().put("maxOutputTokens", 2048))
        if (systemPrompt.isNotBlank()) {
            bodyJson.put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", systemPrompt))))
        }
        val base = normalized.removeSuffix("/v1beta").removeSuffix("/v1")
        val url = "$base/v1beta/models/${model.trim()}:generateContent".toHttpUrl().newBuilder()
            .addQueryParameter("key", apiKey).build()
        request = Request.Builder().url(url)
            .post(bodyJson.toString().toRequestBody("application/json; charset=utf-8".toMediaType()))
            .header("Content-Type", "application/json")
            .build()
    } else if (isAnthropic) {
        val apiMessages = JSONArray()
        messages.filter { it.role == "user" || it.role == "assistant" }.forEach {
            apiMessages.put(JSONObject().put("role", it.role).put("content", it.content))
        }
        bodyJson = JSONObject().put("model", model).put("max_tokens", 2048).put("messages", apiMessages)
        if (systemPrompt.isNotBlank()) bodyJson.put("system", systemPrompt)
        request = Request.Builder().url(if (normalized.endsWith("/v1")) "$normalized/messages" else "$normalized/v1/messages")
            .post(bodyJson.toString().toRequestBody("application/json; charset=utf-8".toMediaType()))
            .header("Content-Type", "application/json")
            .header("x-api-key", apiKey)
            .header("anthropic-version", "2023-06-01")
            .build()
    } else {
        val jsonMessages = JSONArray()
        if (systemPrompt.isNotBlank()) jsonMessages.put(JSONObject().put("role", "system").put("content", systemPrompt))
        messages.forEach { jsonMessages.put(JSONObject().put("role", it.role).put("content", it.content)) }
        bodyJson = JSONObject().put("model", model).put("messages", jsonMessages)
        request = Request.Builder().url("$normalized/chat/completions")
            .post(bodyJson.toString().toRequestBody("application/json; charset=utf-8".toMediaType()))
            .header("Content-Type", "application/json")
            .header("Authorization", "Bearer $apiKey")
            .build()
    }

    val response = client.newCall(request).execute()
    response.use {
        val responseText = it.body?.string().orEmpty()
        if (!it.isSuccessful) throw IllegalStateException("الخادم رجع HTTP ${it.code}: ${responseText.take(220)}")
        val root = JSONObject(responseText)
        val answer = when {
            isGemini -> root.optJSONArray("candidates")?.optJSONObject(0)
                ?.optJSONObject("content")?.optJSONArray("parts")?.let { parts ->
                    (0 until parts.length()).mapNotNull { index -> parts.optJSONObject(index)?.optString("text") }
                        .filter { text -> text.isNotBlank() }.joinToString("\n")
                }
            isAnthropic -> root.optJSONArray("content")?.optJSONObject(0)?.optString("text")
            else -> root.optJSONArray("choices")?.optJSONObject(0)?.optJSONObject("message")?.optString("content")
        }
        answer?.takeIf { content -> content.isNotBlank() }
            ?: throw IllegalStateException("ما وصل رد نصي من النموذج. تحقق من اسم الموديل وإعدادات API")
    }
}
