# BHH AI — Android starter with Google Gemini support

واجهة دردشة عربية RTL داكنة بلمسات بنفسجية. يدعم Google Gemini API وClaude API والخوادم المتوافقة مع OpenAI Chat Completions.

## إعداد Gemini
1. أنشئ مفتاحاً من https://aistudio.google.com/apikey
2. افتح إعدادات التطبيق.
3. عنوان API: `https://generativelanguage.googleapis.com/v1beta`
4. اسم الموديل: `gemini-2.5-flash` (تحقق من الموديلات المتاحة في حسابك إن لم يعمل).
5. الصق مفتاح API واحفظ ثم جرّب إرسال رسالة.

## بناء APK
1. فك ضغط المشروع.
2. افتح مجلد `BHH_AI_Android_Starter` في Android Studio.
3. انتظر Gradle Sync واكمل تثبيت Android SDK إذا طلبه البرنامج.
4. من القائمة اختر Build > Build Bundle(s) / APK(s) > Build APK(s).
5. غالباً يظهر الملف في `app/build/outputs/apk/debug/app-debug.apk`.

مهم: هذا ملف مشروع مصدر وليس APK جاهزاً. لم يتم بناء APK أو اختباره في بيئة Android SDK هنا. احتفظ بمفتاح API سرياً؛ تضمينه داخل التطبيق مناسب للاختبار الشخصي فقط، وليس للنشر العام. لتطبيق منشور، استخدم خادماً وسيطاً يحفظ المفتاح بأمان.
